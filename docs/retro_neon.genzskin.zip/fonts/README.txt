Drop .ttf/.otf files here and set "font": "fonts/YourFont.ttf" in theme.json
