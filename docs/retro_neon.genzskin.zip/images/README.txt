Drop bg.jpg here and add "backgroundImage": "images/bg.jpg" to theme.json
